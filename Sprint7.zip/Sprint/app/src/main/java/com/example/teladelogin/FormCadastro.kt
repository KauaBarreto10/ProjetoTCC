package com.example.teladelogin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import models.LoginResponse
import org.json.JSONObject

class FormCadastro : AppCompatActivity() {

    var name = ""
    var email = ""
    var address = ""
    var telefone = ""
    var password = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_form_cadastro)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val botaoEntrar: Button = findViewById(R.id.btEntrar)
        botaoEntrar.setOnClickListener {
            if (isValidInput()) {
                cadastrar()


            } else {
                Toast.makeText(this, "Por favor, preencha todos os campos corretamente.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun cadastrar(): String {
        val queue = Volley.newRequestQueue(this)
        val url = "http://177.220.18.58:3001/add-client"
        var response = ""

        val stringRequest = object : StringRequest(

            Request.Method.POST,
            url, {
                // Handling Success
                Log.d("Success", "simpleRequest:${it}")
                response = it
                val intent = Intent(this, TelaCadastro::class.java)
                startActivity(intent)
                finish()
            },

            {
                // Handling Error
                Log.d("Error", "simpleRequest:${it}")
                response = "Error"
            }) {
            override fun getBodyContentType(): String {
                return "application/json"
            }

            /*
            * {
            "nome": "Kaua",
            "email":"cc22639@gmail.com",
            "telefone": "40028922",
            "endereco": "Rua culto a ciencia, 177"
             "senha: ******"
             * }*/

            override fun getBody(): ByteArray {
                val params2 = HashMap<String, String>()
                params2.put("nome",name)
                params2.put("email", email)
                params2.put("telefone", telefone)
                params2.put("endereco", address)
                params2.put("senha", password)
                return JSONObject(params2 as Map<*, *>?).toString().toByteArray()
            }
        }
        queue.add(stringRequest)
        Log.d("X",response.toString())
        return response
    }

    private fun isValidInput(): Boolean {
        val editTextName: EditText = findViewById(R.id.editTextName)
        val editTextEmail: EditText = findViewById(R.id.editTextEmail)
        val editTextAddress: EditText = findViewById(R.id.editTextAddress)
        val editTextTelefone: EditText = findViewById(R.id.editTextAge) //telefone
        val editTextPassword: EditText = findViewById(R.id.editTextPassword)

        name = editTextName.text.toString().trim()
        email = editTextEmail.text.toString().trim()
        address = editTextAddress.text.toString().trim()
        telefone = editTextTelefone.text.toString().trim()
        password = editTextPassword.text.toString().trim()

        return when {
            name.isEmpty() -> {
                showToast("O campo nome é obrigatório.")
                false
            }
            email.isEmpty() || !email.endsWith("@gmail.com") -> {
                showToast("Insira um e-mail válido com @gmail.com.")
                false
            }
            address.isEmpty() || !address.contains(" ") -> {
                showToast("O campo endereço deve conter o nome da rua e o número da residência.")
                false
            }
            password.isEmpty() || password.length < 6 -> {
                showToast("A senha deve ter pelo menos 6 caracteres.")
                false
            }
            else -> true
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
