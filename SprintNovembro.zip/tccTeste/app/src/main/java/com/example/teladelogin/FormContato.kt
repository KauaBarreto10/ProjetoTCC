package com.example.teladelogin

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import android.util.Log

class FormContato : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_contato)

        // Lista de contatos
        val contatos = listOf(
            Contato(
                nome = "Psicóloga Mariane Preda de Melo",
                endereco = "Rua Barão de Paranapanema, 146 - Bloco A",
                telefone = "(19) 97824-0207"
            ),
            Contato(
                nome = "Bem Viver Mais - Terapias Integradas",
                endereco = "R: Barreto Leme, 1887",
                telefone = "(19) 98112-4133"
            ),
            Contato(
                nome = "Psicóloga Drª Vânia Ramos - [Clínica Tecer]",
                endereco = "Av. Aquidabã, 883 - 5º Andar Sala 52",
                telefone = "(19) 99445-3145"
            )
        )

        // Configurando o RecyclerView
        val recyclerView: RecyclerView = findViewById(R.id.recyclerViewContatos)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ContatosAdapter(contatos)

        // Configurando o botão para ir para a próxima página
        val botaoProximaPagina: Button = findViewById(R.id.btnProximaPagina)
        botaoProximaPagina.setOnClickListener {
            Log.d("FormContato", "Botão de próxima página clicado")
            // Navegar para a TelaContatoParentes
            val intent = Intent(this, TelaContatoParentes::class.java)
            startActivity(intent)
        }
    }
}
