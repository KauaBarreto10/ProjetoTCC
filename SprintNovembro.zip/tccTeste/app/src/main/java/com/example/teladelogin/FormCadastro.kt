package com.example.teladelogin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import models.LoginResponse
import org.json.JSONObject

class FormCadastro : AppCompatActivity() {

    var name = ""
    var email = ""
    var address = ""
    var telefone = ""
    var password = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_form_cadastro)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val botaoEntrar: Button = findViewById(R.id.btEntrar)
        botaoEntrar.setOnClickListener {
            if (isValidInput()) {
                cadastrar()


            } else {
                Toast.makeText(this, "Por favor, preencha todos os campos corretamente.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun cadastrar() {
        val queue = Volley.newRequestQueue(this)
        val url = "http://177.220.18.58:3000/add-client"

        val stringRequest = object : StringRequest(
            Request.Method.POST,
            url,
            Response.Listener { response ->
                // Handling Success
                Log.d("Success", "Cadastro bem-sucedido: $response")
                Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, TelaCadastro::class.java)  // Navega para a tela de login
                startActivity(intent)
                finish()
            },
            Response.ErrorListener { error ->
                // Handling Error
                Log.d("Error", "Erro ao cadastrar: ${error.message}")
                Toast.makeText(this, "Erro ao cadastrar. Tente novamente.", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getBodyContentType(): String {
                return "application/json"
            }

            override fun getBody(): ByteArray {
                val params = mapOf(
                    "nome" to name,
                    "email" to email,
                    "telefone" to telefone,
                    "endereco" to address,
                    "senha" to password
                )
                return JSONObject(params).toString().toByteArray()
            }
        }
            queue.add(stringRequest)

    }

    private fun isValidInput(): Boolean {
        val editTextName: EditText = findViewById(R.id.editTextName)
        val editTextEmail: EditText = findViewById(R.id.editTextEmail)
        val editTextAddress: EditText = findViewById(R.id.editTextAddress)
        val editTextTelefone: EditText = findViewById(R.id.editTextAge) //telefone
        val editTextPassword: EditText = findViewById(R.id.editTextPassword)

        name = editTextName.text.toString().trim()
        email = editTextEmail.text.toString().trim()
        address = editTextAddress.text.toString().trim()
        telefone = editTextTelefone.text.toString().trim()
        password = editTextPassword.text.toString().trim()

        return when {
            name.isEmpty() -> {
                showToast("O campo nome é obrigatório.")
                false
            }
            email.isEmpty() || !email.endsWith("@gmail.com") -> {
                showToast("Insira um e-mail válido com @gmail.com.")
                false
            }
            address.isEmpty() || !address.contains(" ") -> {
                showToast("O campo endereço deve conter o nome da rua e o número da residência.")
                false
            }
            password.isEmpty() || password.length < 6 -> {
                showToast("A senha deve ter pelo menos 6 caracteres.")
                false
            }
            else -> true
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
