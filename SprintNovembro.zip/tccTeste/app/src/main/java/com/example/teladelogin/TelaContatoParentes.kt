package com.example.teladelogin

import android.os.Bundle
import android.text.InputFilter
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class TelaContatoParentes : AppCompatActivity() {
    private lateinit var telefoneParente1: EditText
    private lateinit var telefoneParente2: EditText
    private lateinit var telefoneParente3: EditText
    private lateinit var botaoSalvarContatos: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tela_contato_parentes)

        // Configuração para ajustar o layout ao utilizar Edge-to-Edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inicializando os componentes de UI
        telefoneParente1 = findViewById(R.id.telefoneParente1)
        telefoneParente2 = findViewById(R.id.telefoneParente2)
        telefoneParente3 = findViewById(R.id.telefoneParente3)
        botaoSalvarContatos = findViewById(R.id.btnSalvarContatos)

        // Definindo limite de 11 caracteres para cada campo de telefone
        val maxLength = 12
        val filterArray = arrayOf(InputFilter.LengthFilter(maxLength))

        telefoneParente1.filters = filterArray
        telefoneParente2.filters = filterArray
        telefoneParente3.filters = filterArray

        // Configurando o evento de clique do botão "Salvar Contatos"
        botaoSalvarContatos.setOnClickListener {
            val numero1 = telefoneParente1.text.toString()
            val numero2 = telefoneParente2.text.toString()
            val numero3 = telefoneParente3.text.toString()

            // Verificação simples para garantir que os campos não estejam vazios
            if (numero1.isEmpty() && numero2.isEmpty() && numero3.isEmpty()) {
                Toast.makeText(this, "Por favor, insira pelo menos um número de telefone.", Toast.LENGTH_SHORT).show()
            } else {
                // Ação para salvar ou utilizar os números de telefone
                Toast.makeText(this, "Contatos salvos:\n1: $numero1\n2: $numero2\n3: $numero3", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
