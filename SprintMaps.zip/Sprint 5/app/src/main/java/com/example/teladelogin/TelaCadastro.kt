package com.example.teladelogin

import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import com.example.teladelogin.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class TelaCadastro : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = Color.parseColor("#FFFFFF")

        binding.btEntrar.setOnClickListener {
            val email = binding.editEmail.text.toString()
            val senha = binding.editSenha.text.toString()

            // Verificar se email e senha estão cadastrados no SharedPreferences
            val sharedPreferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
            val emailCadastrado = sharedPreferences.getString("email", null)
            val senhaCadastrada = sharedPreferences.getString("senha", null)

            when {
                email.isEmpty() -> {
                    binding.editEmail.error = "Preencha o e-mail"
                }

                senha.isEmpty() -> {
                    binding.editSenha.error = "Preencha a senha"
                }

                !email.contains("@gmail.com") -> {
                    val snackbar = Snackbar.make(it, "E-mail inválido!", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }

                senha.length <= 5 -> {
                    val snackbar = Snackbar.make(
                        it,
                        "A senha precisa ter pelo menos 6 caracteres!",
                        Snackbar.LENGTH_SHORT
                    )
                    snackbar.show()
                }

                // Verificar se o e-mail e a senha correspondem ao que já foi cadastrado
                email != emailCadastrado || senha != senhaCadastrada -> {
                    val snackbar = Snackbar.make(it, "Conta não encontrada. Crie uma conta primeiro.", Snackbar.LENGTH_SHORT)
                    snackbar.show()
                }

                else -> {
                    login(it)
                }
            }
        }

        binding.txtTelaCadastro.setOnClickListener {
            navegarParaFormCadastro()
        }
    }

    private fun login(view: View) {
        val progressbar = binding.progressBar
        progressbar.visibility = View.VISIBLE

        binding.btEntrar.isEnabled = false
        binding.btEntrar.setTextColor(Color.parseColor("#FFFFFF"))

        Handler(Looper.getMainLooper()).postDelayed(
            {
                navegarTelaPrincipal()
                val snackbar = Snackbar.make(view, "Login efetuado com sucesso!", Snackbar.LENGTH_SHORT)
                snackbar.show()
            }, 3000
        )
    }

    private fun navegarTelaPrincipal() {
        val intent = Intent(this, TelaPrincipal::class.java)
        startActivity(intent)
        finish()
    }

    private fun navegarParaFormCadastro() {
        val intent = Intent(this, FormCadastro::class.java)
        startActivity(intent)
    }
}
