const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const connection = mysql.createConnection({
  host: 'regulus.cotuca.unicamp.br',   
  user: 'BD22639',        
  password: 'BD22639', 
  database: 'BD22639'   
});

connection.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados MySQL');
});

app.post('/add-client', (req, res) => {
  const { nome, email, telefone, endereco } = req.body;
  const sql = 'INSERT INTO Cliente (nome, email, telefone, endereco) VALUES (?, ?, ?, ?)';
  connection.query(sql, [nome, email, telefone, endereco], (err, results) => {
    if (err) {
      console.error('Erro ao adicionar cliente:', err);
      res.status(500).json({ error: 'Erro ao adicionar cliente' });
    } else {
      res.status(201).json({ message: 'Cliente adicionado com sucesso' });
    }
  });
});

app.post('/register-login', (req, res) => {
  const { email, senha } = req.body;
  const sql = 'INSERT INTO Login (email, senha) VALUES (?, ?)';
  connection.query(sql, [email, senha], (err, results) => {
    if (err) {
      console.error('Erro ao registrar login:', err);
      res.status(500).json({ error: 'Erro ao registrar login' });
    } else {
      res.status(201).json({ message: 'Login registrado com sucesso' });
    }
  });
});

app.post('/login', (req, res) => {
  const { email, senha } = req.body;
  const sql = 'SELECT * FROM Login WHERE email = ? AND senha = ?';
  connection.query(sql, [email, senha], (err, results) => {
    if (err) {
      console.error('Erro ao fazer login:', err);
      res.status(500).json({ error: 'Erro ao fazer login' });
    } else if (results.length > 0) {
      res.status(200).json({ message: 'Login bem-sucedido' });
    } else {
      res.status(401).json({ error: 'Credenciais inválidas' });
    }
  });
});

app.post('/add-user', (req, res) => {
  const { nome, endereco, idade } = req.body;
  const sql = 'INSERT INTO Usuario (nome, endereco, idade) VALUES (?, ?, ?)';
  connection.query(sql, [nome, endereco, idade], (err, results) => {
    if (err) {
      console.error('Erro ao adicionar usuário:', err);
      res.status(500).json({ error: 'Erro ao adicionar usuário' });
    } else {
      res.status(201).json({ message: 'Usuário adicionado com sucesso' });
    }
  });
});

app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});
