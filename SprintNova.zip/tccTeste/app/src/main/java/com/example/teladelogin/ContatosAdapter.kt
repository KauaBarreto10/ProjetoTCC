package com.example.teladelogin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView

class ContatosAdapter(private val contatos: List<Contato>) : RecyclerView.Adapter<ContatosAdapter.ContatoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContatoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_contato, parent, false)
        return ContatoViewHolder(view)
    }

    override fun onBindViewHolder(holder: ContatoViewHolder, position: Int) {
        val contato = contatos[position]
        holder.tvNome.text = contato.nome
        holder.tvEndereco.text = contato.endereco
        holder.tvTelefone.text = contato.telefone
    }

    override fun getItemCount(): Int = contatos.size

    // ViewHolder
    class ContatoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNome: TextView = itemView.findViewById(R.id.tvNome)
        val tvEndereco: TextView = itemView.findViewById(R.id.tvEndereco)
        val tvTelefone: TextView = itemView.findViewById(R.id.tvTelefone)
    }
}
