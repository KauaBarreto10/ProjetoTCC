package com.example.teladelogin

data class Contato(
    val nome: String,
    val endereco: String,
    val telefone: String
)
