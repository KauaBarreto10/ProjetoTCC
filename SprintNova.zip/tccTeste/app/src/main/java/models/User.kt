package models

data class User(
    val nome: String,
    val endereco: String,
    val idade: Int
)
