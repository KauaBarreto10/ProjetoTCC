package models

data class Client(
    val nome: String,
    val email: String,
    val telefone: String,
    val endereco: String
)
