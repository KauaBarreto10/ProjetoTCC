package models

data class LoginResponse(
    val message: String
)