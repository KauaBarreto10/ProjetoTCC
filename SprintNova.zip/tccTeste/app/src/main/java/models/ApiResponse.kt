package models


data class ApiResponse(
    val message: String
)
